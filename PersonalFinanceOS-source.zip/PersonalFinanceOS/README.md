# Personal Finance OS (Android MVP)

A local-first Android app for monthly budget planning. Built with Kotlin, Jetpack Compose, Room, and WorkManager.

## Included
- Actual account balance input. The budget engine uses only the balance you explicitly enter; future salary and credit limits are excluded.
- Fixed monthly savings target (default ₹10,000).
- Mandatory monthly budget defaults: rent ₹8,500, food ₹5,000, medicine ₹799, ChatGPT ₹399, Netflix ₹199.
- Unpaid credit-card dues field and automatic adjustments for recorded HDFC Credit purchases / card payments.
- Transaction history and category, payment-source, and transaction-type fields.
- Monthly spending total counts EXPENSE transactions, net of refunds. CARD_PAYMENT and SAVINGS_TRANSFER are not treated as new expenses.
- Local database storage with Room.
- Daily background reminder checks on the 1st (rent), 5th (medicine), 10th (subscriptions), and 25th (monthly review).
- Budget alerts when actual funds cannot cover card dues, savings target, and remaining mandatory costs.

## Open in Android Studio
1. Unzip the project.
2. Open the `PersonalFinanceOS` folder in Android Studio.
3. Use JDK 17 and allow Gradle sync to download the Android Gradle Plugin and dependencies.
4. Run on an Android 8.0+ device or emulator.

## Important behavior
- This MVP does **not** connect directly to HDFC or scrape banking apps. Enter the current available bank balance in Rules and update it when your real balance changes.
- Expected salary, credit limit, and unconfirmed incoming money are never included in capacity.
- Credit-card purchase is recorded as an expense and increases tracked card dues. Recording a card bill payment reduces dues but does not add a second expense. Update the actual account balance after the real payment has posted.
- Savings is reserved virtually in the plan. The app does not move money automatically.
- Reminder checks run periodically in the background, so exact notification timing depends on Android battery/background scheduling. Notification permission is requested on Android 13+.
- Data is stored locally on the device. No account credentials, card PINs, CVVs, or OTPs are requested.

## Known MVP limitations / next steps
- No automatic bank sync, SMS parsing, CSV import/export, or cloud backup yet.
- Card dues are tracked as one total, not by statement cycle or individual card statement.
- Reminders use default dates and do not yet support per-bill custom due dates.
- This source project is provided for Android Studio; it has not been signed or published as a Play Store APK.
