package com.dipro.finance

import com.dipro.finance.data.FinanceSettings
import com.dipro.finance.data.FinanceTransaction
import java.time.Instant
import java.time.ZoneId
import java.time.YearMonth

/** Deterministic rules engine. All money values are integer paise to avoid floating-point errors. */
object BudgetEngine {
    data class Plan(
        val actualBalancePaise: Long,
        val cardDuesPaise: Long,
        val savingsTargetPaise: Long,
        val savingsReservedPaise: Long,
        val mandatoryRemainingPaise: Long,
        val mandatoryReservedPaise: Long,
        val discretionaryPaise: Long,
        val monthlyExpensesPaise: Long,
        val monthlyMandatorySpentPaise: Long,
        val shortfallPaise: Long,
        val savingsShortfallPaise: Long
    )

    fun calculate(settings: FinanceSettings, transactions: List<FinanceTransaction>, nowMillis: Long = System.currentTimeMillis()): Plan {
        val zone = ZoneId.systemDefault()
        val currentMonth = YearMonth.from(Instant.ofEpochMilli(nowMillis).atZone(zone))
        val monthTx = transactions.filter { YearMonth.from(Instant.ofEpochMilli(it.dateMillis).atZone(zone)) == currentMonth }
        val monthlyExpenses = monthTx.filter { it.type == "EXPENSE" }.sumOf { it.amountPaise } - monthTx.filter { it.type == "REFUND" }.sumOf { it.amountPaise }
        val mandatoryCategories = setOf("Rent", "Food", "Medicine", "Subscription", "Other mandatory")
        val mandatorySpent = monthTx.filter { it.type == "EXPENSE" && it.category in mandatoryCategories }.sumOf { it.amountPaise }
        val mandatoryRemaining = (settings.mandatoryTotalPaise - mandatorySpent).coerceAtLeast(0L)
        val availableAfterDues = (settings.actualBalancePaise - settings.unpaidCardDuesPaise).coerceAtLeast(0L)
        val savingsReserved = minOf(settings.savingsTargetPaise, availableAfterDues)
        val afterSavings = (availableAfterDues - savingsReserved).coerceAtLeast(0L)
        val mandatoryReserved = minOf(mandatoryRemaining, afterSavings)
        val discretionary = (afterSavings - mandatoryReserved).coerceAtLeast(0L)
        val totalNeeds = settings.unpaidCardDuesPaise + settings.savingsTargetPaise + mandatoryRemaining
        val shortfall = (totalNeeds - settings.actualBalancePaise).coerceAtLeast(0L)
        val savingsShortfall = (settings.savingsTargetPaise - savingsReserved).coerceAtLeast(0L)
        return Plan(settings.actualBalancePaise, settings.unpaidCardDuesPaise, settings.savingsTargetPaise, savingsReserved,
            mandatoryRemaining, mandatoryReserved, discretionary, monthlyExpenses.coerceAtLeast(0L), mandatorySpent,
            shortfall, savingsShortfall)
    }
}
