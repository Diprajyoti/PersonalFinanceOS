package com.dipro.finance

import android.Manifest
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import com.dipro.finance.data.FinanceDatabase
import com.dipro.finance.data.FinanceSettings
import com.dipro.finance.data.FinanceTransaction
import kotlinx.coroutines.launch
import java.text.NumberFormat
import java.time.Instant
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.util.Locale
import java.util.concurrent.TimeUnit

class MainActivity : ComponentActivity() {
    private val notificationPermission = registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 33) notificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        val request = PeriodicWorkRequestBuilder<ReminderWorker>(24, TimeUnit.HOURS).build()
        WorkManager.getInstance(this).enqueueUniquePeriodicWork("finance_daily_reminders", ExistingPeriodicWorkPolicy.KEEP, request)
        val dao = FinanceDatabase.get(this).financeDao()
        setContent { FinanceApp(dao = dao) }
    }
}

private enum class AppTab(val title: String) { DASHBOARD("Overview"), TRANSACTIONS("Transactions"), RULES("Rules") }

@Composable
private fun FinanceApp(dao: com.dipro.finance.data.FinanceDao) {
    val scope = rememberCoroutineScope()
    val settingsObserved by dao.observeSettings().collectAsState(initial = null)
    val transactions by dao.observeTransactions().collectAsState(initial = emptyList())
    var tab by remember { mutableStateOf(AppTab.DASHBOARD) }
    var showAdd by remember { mutableStateOf(false) }
    var settings by remember { mutableStateOf(FinanceSettings()) }

    LaunchedEffect(settingsObserved) {
        if (settingsObserved == null) dao.saveSettings(FinanceSettings()) else settings = settingsObserved!!
    }
    LaunchedEffect(settingsObserved) { settingsObserved?.let { settings = it } }
    val plan = remember(settings, transactions) { BudgetEngine.calculate(settings, transactions) }

    MaterialTheme(colorScheme = lightColorScheme()) {
        Scaffold(
            topBar = {
                Surface(tonalElevation = 2.dp) {
                    Column(Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 14.dp)) {
                        Text("Personal Finance OS", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                        Text("Your money. One clear monthly plan.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            },
            bottomBar = {
                NavigationBar {
                    AppTab.entries.forEach { item ->
                        NavigationBarItem(selected = tab == item, onClick = { tab = item }, icon = { Text(when(item) { AppTab.DASHBOARD -> "₹"; AppTab.TRANSACTIONS -> "↕"; AppTab.RULES -> "⚙" }) }, label = { Text(item.title) })
                    }
                }
            },
            floatingActionButton = {
                if (tab != AppTab.RULES) FloatingActionButton(onClick = { showAdd = true }) { Text("+") }
            }
        ) { padding ->
            when (tab) {
                AppTab.DASHBOARD -> DashboardScreen(Modifier.padding(padding), settings, plan, transactions.size, onAdd = { showAdd = true }, onGoRules = { tab = AppTab.RULES })
                AppTab.TRANSACTIONS -> TransactionsScreen(Modifier.padding(padding), transactions, onDelete = { id -> scope.launch { dao.deleteTransaction(id) } })
                AppTab.RULES -> RulesScreen(Modifier.padding(padding), settings, onSave = { newSettings -> scope.launch { dao.saveSettings(newSettings) } })
            }
        }
        if (showAdd) AddTransactionDialog(onDismiss = { showAdd = false }, onSave = { amount, category, source, type, note ->
            val paise = (amount * 100).toLong()
            scope.launch {
                dao.insertTransaction(FinanceTransaction(amountPaise = paise, category = category, paymentSource = source, type = type, note = note))
                val current = settingsObserved ?: settings
                val updatedDues = when {
                    type == "EXPENSE" && source == "HDFC Credit" -> current.unpaidCardDuesPaise + paise
                    type == "CARD_PAYMENT" -> (current.unpaidCardDuesPaise - paise).coerceAtLeast(0L)
                    else -> current.unpaidCardDuesPaise
                }
                dao.saveSettings(current.copy(unpaidCardDuesPaise = updatedDues))
            }
            showAdd = false
        })
    }
}

@Composable
private fun DashboardScreen(
    modifier: Modifier, settings: FinanceSettings, plan: BudgetEngine.Plan, transactionCount: Int,
    onAdd: () -> Unit, onGoRules: () -> Unit
) {
    LazyColumn(modifier.fillMaxSize(), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item {
            Card(shape = RoundedCornerShape(22.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)) {
                Column(Modifier.fillMaxWidth().padding(18.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("Available for discretionary spending", style = MaterialTheme.typography.titleMedium)
                    Text(money(plan.discretionaryPaise), style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.Bold)
                    Text("After card dues, savings reserve and remaining mandatory expenses", style = MaterialTheme.typography.bodySmall)
                }
            }
        }
        item { Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            MetricCard("Actual account balance", money(settings.actualBalancePaise), Modifier.weight(1f))
            MetricCard("This month's spending", money(plan.monthlyExpensesPaise), Modifier.weight(1f))
        } }
        item { Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            MetricCard("Savings reserved", money(plan.savingsReservedPaise), Modifier.weight(1f))
            MetricCard("Mandatory reserve", money(plan.mandatoryReservedPaise), Modifier.weight(1f))
        } }
        item {
            val savingsGap = plan.savingsShortfallPaise
            val needsAttention = plan.shortfallPaise > 0
            Card {
                Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(if (needsAttention) "Plan needs attention" else "Your plan is funded", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                    if (needsAttention) {
                        Text("Your actual balance is short by ${money(plan.shortfallPaise)} to cover the current card dues, savings target and remaining mandatory budget.")
                        if (savingsGap > 0) Text("Savings target shortfall: ${money(savingsGap)}")
                    } else Text("Card dues and this month's savings and mandatory reserves fit within the actual balance.")
                    Text("Unpaid card dues: ${money(settings.unpaidCardDuesPaise)}")
                    Text("Mandatory expenses still to cover: ${money(plan.mandatoryRemainingPaise)}")
                    Text("Monthly transactions recorded: $transactionCount")
                }
            }
        }
        item {
            Card {
                Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Monthly rules", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                    Text("Savings target: ${money(settings.savingsTargetPaise)}")
                    Text("Mandatory monthly total: ${money(settings.mandatoryTotalPaise)}")
                    Text("Balance last updated: ${if (settings.balanceUpdatedMillis == 0L) "Not recorded" else formatDate(settings.balanceUpdatedMillis)}")
                    OutlinedButton(onClick = onGoRules, modifier = Modifier.fillMaxWidth()) { Text("Update balance and rules") }
                }
            }
        }
        item { OutlinedButton(onClick = onAdd, modifier = Modifier.fillMaxWidth()) { Text("+ Add a transaction") } }
        item { Text("Reminder dates: rent check on the 1st, medicine on the 5th, subscriptions on the 10th, monthly review on the 25th.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant) }
    }
}

@Composable
private fun MetricCard(title: String, value: String, modifier: Modifier = Modifier) {
    Card(modifier) { Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Text(title, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(value, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
    } }
}

@Composable
private fun TransactionsScreen(modifier: Modifier, transactions: List<FinanceTransaction>, onDelete: (Long) -> Unit) {
    if (transactions.isEmpty()) {
        Box(modifier.fillMaxSize().padding(24.dp), contentAlignment = Alignment.Center) {
            Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("No transactions yet", style = MaterialTheme.typography.titleLarge)
                Text("Add expenses, income, card payments or refunds. Monthly spending counts purchases once, not card bill settlements.")
            }
        }
    } else LazyColumn(modifier.fillMaxSize(), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        items(transactions, key = { it.id }) { tx ->
            Card {
                Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                        Text(tx.category, fontWeight = FontWeight.SemiBold)
                        Text("${tx.type.replace('_', ' ')} • ${tx.paymentSource}", style = MaterialTheme.typography.bodySmall)
                        if (tx.note.isNotBlank()) Text(tx.note, style = MaterialTheme.typography.bodySmall)
                        Text(formatDate(tx.dateMillis), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    Column(horizontalAlignment = Alignment.End) {
                        Text(money(tx.amountPaise), fontWeight = FontWeight.Bold)
                        TextButton(onClick = { onDelete(tx.id) }, contentPadding = PaddingValues(0.dp)) { Text("Delete") }
                    }
                }
            }
        }
    }
}

@Composable
private fun RulesScreen(modifier: Modifier, current: FinanceSettings, onSave: (FinanceSettings) -> Unit) {
    var balance by remember(current) { mutableStateOf(rupeesInput(current.actualBalancePaise)) }
    var savings by remember(current) { mutableStateOf(rupeesInput(current.savingsTargetPaise)) }
    var rent by remember(current) { mutableStateOf(rupeesInput(current.rentPaise)) }
    var food by remember(current) { mutableStateOf(rupeesInput(current.foodPaise)) }
    var medicine by remember(current) { mutableStateOf(rupeesInput(current.medicinePaise)) }
    var chatgpt by remember(current) { mutableStateOf(rupeesInput(current.chatGptPaise)) }
    var netflix by remember(current) { mutableStateOf(rupeesInput(current.netflixPaise)) }
    var other by remember(current) { mutableStateOf(rupeesInput(current.otherMandatoryPaise)) }
    var dues by remember(current) { mutableStateOf(rupeesInput(current.unpaidCardDuesPaise)) }
    var savedMessage by remember { mutableStateOf(false) }

    LazyColumn(modifier.fillMaxSize(), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item { Text("Your financial rules", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold) }
        item { Text("Enter the actual balance currently available in your account. Expected salary and credit limit are never included.", style = MaterialTheme.typography.bodyMedium) }
        item { MoneyField("Actual available account balance (₹)", balance) { balance = it; savedMessage = false } }
        item { MoneyField("Unpaid credit-card dues (₹)", dues) { dues = it; savedMessage = false } }
        item { Divider() }
        item { Text("Savings target", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold) }
        item { MoneyField("Monthly savings target (₹)", savings) { savings = it; savedMessage = false } }
        item { Text("Mandatory monthly expenses", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold) }
        item { MoneyField("Rent (₹)", rent) { rent = it; savedMessage = false } }
        item { MoneyField("Food (₹)", food) { food = it; savedMessage = false } }
        item { MoneyField("Medicine (₹)", medicine) { medicine = it; savedMessage = false } }
        item { MoneyField("ChatGPT subscription (₹)", chatgpt) { chatgpt = it; savedMessage = false } }
        item { MoneyField("Netflix subscription (₹)", netflix) { netflix = it; savedMessage = false } }
        item { MoneyField("Other mandatory expenses (₹)", other) { other = it; savedMessage = false } }
        item {
            Text("Monthly mandatory total: ${money(parsePaise(rent) + parsePaise(food) + parsePaise(medicine) + parsePaise(chatgpt) + parsePaise(netflix) + parsePaise(other))}", fontWeight = FontWeight.Bold)
        }
        item {
            Button(onClick = {
                onSave(current.copy(
                    actualBalancePaise = parsePaise(balance), savingsTargetPaise = parsePaise(savings),
                    rentPaise = parsePaise(rent), foodPaise = parsePaise(food), medicinePaise = parsePaise(medicine),
                    chatGptPaise = parsePaise(chatgpt), netflixPaise = parsePaise(netflix), otherMandatoryPaise = parsePaise(other),
                    unpaidCardDuesPaise = parsePaise(dues), balanceUpdatedMillis = System.currentTimeMillis()
                ))
                savedMessage = true
            }, modifier = Modifier.fillMaxWidth()) { Text("Save rules and balance") }
        }
        if (savedMessage) item { Text("Saved on this device.", color = MaterialTheme.colorScheme.primary) }
        item { Text("Important: update the balance when your bank balance changes. Recording a transaction does not pretend to know the live bank balance.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant) }
    }
}

@Composable
private fun MoneyField(label: String, value: String, onValueChange: (String) -> Unit) {
    OutlinedTextField(value = value, onValueChange = { input -> onValueChange(input.filter { it.isDigit() || it == '.' }.take(12)) },
        label = { Text(label) }, modifier = Modifier.fillMaxWidth(), singleLine = true,
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal))
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun AddTransactionDialog(
    onDismiss: () -> Unit,
    onSave: (Double, String, String, String, String) -> Unit
) {
    var amount by remember { mutableStateOf("") }
    var category by remember { mutableStateOf("Food") }
    var source by remember { mutableStateOf("HDFC Debit") }
    var type by remember { mutableStateOf("EXPENSE") }
    var note by remember { mutableStateOf("") }
    val categories = listOf("Food", "Rent", "Medicine", "Subscription", "Art", "Travel", "Shopping", "Other mandatory", "Other")
    val sources = listOf("HDFC Debit", "HDFC Credit", "Cash", "Bank transfer", "Other")
    val types = listOf("EXPENSE", "INCOME", "CARD_PAYMENT", "REFUND", "SAVINGS_TRANSFER")
    var catExpanded by remember { mutableStateOf(false) }
    var sourceExpanded by remember { mutableStateOf(false) }
    var typeExpanded by remember { mutableStateOf(false) }

    AlertDialog(onDismissRequest = onDismiss, title = { Text("Add transaction") }, text = {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(amount, { amount = it.filter { c -> c.isDigit() || c == '.' }.take(12) }, label = { Text("Amount (₹)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), singleLine = true)
            ExposedDropdownMenuBox(expanded = catExpanded, onExpandedChange = { catExpanded = it }) {
                OutlinedTextField(category, {}, readOnly = true, label = { Text("Category") }, trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(catExpanded) }, modifier = Modifier.menuAnchor().fillMaxWidth())
                ExposedDropdownMenu(expanded = catExpanded, onDismissRequest = { catExpanded = false }) { categories.forEach { item -> DropdownMenuItem(text = { Text(item) }, onClick = { category = item; catExpanded = false }) } }
            }
            ExposedDropdownMenuBox(expanded = sourceExpanded, onExpandedChange = { sourceExpanded = it }) {
                OutlinedTextField(source, {}, readOnly = true, label = { Text("Payment source") }, trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(sourceExpanded) }, modifier = Modifier.menuAnchor().fillMaxWidth())
                ExposedDropdownMenu(expanded = sourceExpanded, onDismissRequest = { sourceExpanded = false }) { sources.forEach { item -> DropdownMenuItem(text = { Text(item) }, onClick = { source = item; sourceExpanded = false }) } }
            }
            ExposedDropdownMenuBox(expanded = typeExpanded, onExpandedChange = { typeExpanded = it }) {
                OutlinedTextField(type.replace('_', ' '), {}, readOnly = true, label = { Text("Transaction type") }, trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(typeExpanded) }, modifier = Modifier.menuAnchor().fillMaxWidth())
                ExposedDropdownMenu(expanded = typeExpanded, onDismissRequest = { typeExpanded = false }) { types.forEach { item -> DropdownMenuItem(text = { Text(item.replace('_', ' ')) }, onClick = { type = item; typeExpanded = false }) } }
            }
            OutlinedTextField(note, { note = it }, label = { Text("Note (optional)") }, singleLine = true)
            Text("Credit-card purchases add to card dues. Card payments reduce dues but are not counted as new spending.", style = MaterialTheme.typography.bodySmall)
        }
    }, confirmButton = {
        Button(enabled = (amount.toDoubleOrNull() ?: 0.0) > 0, onClick = { onSave(amount.toDouble(), category, source, type, note) }) { Text("Save") }
    }, dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } })
}

private fun money(paise: Long): String {
    val formatter = NumberFormat.getCurrencyInstance(Locale("en", "IN"))
    formatter.maximumFractionDigits = 0
    formatter.minimumFractionDigits = 0
    return formatter.format(paise / 100.0)
}
private fun rupeesInput(paise: Long): String = if (paise % 100 == 0L) (paise / 100).toString() else String.format(Locale.US, "%.2f", paise / 100.0)
private fun parsePaise(value: String): Long = ((value.toDoubleOrNull() ?: 0.0) * 100).toLong().coerceAtLeast(0L)
private fun formatDate(millis: Long): String = Instant.ofEpochMilli(millis).atZone(ZoneId.systemDefault()).format(DateTimeFormatter.ofPattern("dd MMM yyyy", Locale.ENGLISH))
