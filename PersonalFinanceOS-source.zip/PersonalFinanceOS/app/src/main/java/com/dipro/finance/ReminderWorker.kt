package com.dipro.finance

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import java.time.LocalDate

class ReminderWorker(context: Context, params: WorkerParameters) : CoroutineWorker(context, params) {
    override suspend fun doWork(): Result {
        val today = LocalDate.now().dayOfMonth
        val due = when (today) {
            1 -> "Rent reminder: check your rent payment and reserved amount."
            5 -> "Medicine reminder: check your medicine budget and upcoming payment."
            10 -> "Subscription reminder: review ChatGPT/Netflix payments."
            25 -> "Month-end check: review spending and remaining budget."
            else -> null
        } ?: return Result.success()
        val manager = applicationContext.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val channelId = "finance_reminders"
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            manager.createNotificationChannel(NotificationChannel(channelId, "Finance reminders", NotificationManager.IMPORTANCE_DEFAULT))
        }
        if (Build.VERSION.SDK_INT < 33 || ContextCompat.checkSelfPermission(applicationContext, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED) {
            val notification = NotificationCompat.Builder(applicationContext, channelId)
                .setSmallIcon(android.R.drawable.ic_dialog_info)
                .setContentTitle("Personal Finance OS")
                .setContentText(due)
                .setStyle(NotificationCompat.BigTextStyle().bigText(due))
                .setAutoCancel(true).build()
            manager.notify(today, notification)
        }
        return Result.success()
    }
}
