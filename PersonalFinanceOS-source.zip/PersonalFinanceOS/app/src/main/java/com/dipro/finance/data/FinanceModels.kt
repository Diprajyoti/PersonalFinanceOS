package com.dipro.finance.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "transactions")
data class FinanceTransaction(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val dateMillis: Long = System.currentTimeMillis(),
    val amountPaise: Long,
    val category: String,
    val paymentSource: String,
    val type: String, // EXPENSE, INCOME, CARD_PAYMENT, REFUND, SAVINGS_TRANSFER
    val note: String = ""
)

@Entity(tableName = "finance_settings")
data class FinanceSettings(
    @PrimaryKey val id: Int = 1,
    val actualBalancePaise: Long = 0,
    val savingsTargetPaise: Long = 1_000_000,
    val rentPaise: Long = 850_000,
    val foodPaise: Long = 500_000,
    val medicinePaise: Long = 79_900,
    val chatGptPaise: Long = 39_900,
    val netflixPaise: Long = 19_900,
    val otherMandatoryPaise: Long = 0,
    val unpaidCardDuesPaise: Long = 0,
    val balanceUpdatedMillis: Long = 0
) {
    val mandatoryTotalPaise: Long get() = rentPaise + foodPaise + medicinePaise + chatGptPaise + netflixPaise + otherMandatoryPaise
}
